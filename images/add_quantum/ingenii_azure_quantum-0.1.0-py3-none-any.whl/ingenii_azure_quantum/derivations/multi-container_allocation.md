# Multi-container allocation

This notebook is adapted from the 'multi-ship loading' example provided by Azure Quantum, which follows a sample shipping company that wants to balance the loads of container ships at port. In this particular derivation generalize to load-balancing between any number of containers. In addition, we'll see how we can make use of the parameter free-solvers to guide us on a selection of parameters which we can use with the parametrized solvers.

It may be worth reading the [2-container allocation](./2-container_allocation.md) version for a more simple derivation before reading this one.

## The Problem

To tackle this problem we will use a PUBO format. As a reminder, these are [cost functions](https://docs.microsoft.com/en-us/azure/quantum/optimization-concepts-cost-functions) where the variables take the values of either 0 or 1 (rather than -1 or 1 for an Ising cost function).
 
In order to balance weights between multiple containers, one option is to define a cost function that:
1. Penalizes variance from a theoretical equal distribution (where an equal distribution is the total weight of the weights divided by the number of containers), and,
2. Penalizes the assignment of the same weights on multiple containers

We will create two sub cost-functions $H1$ and $H2$ that we will then sum to evaluate the total cost of a solution. Let's begin with the first cost function, $H1$.

## Penalize variance from equal distribution between containers

Suppose we had 3 weights $W0$, $W1$, $W2$, and we define an equal distribution of the container weights to be: 

$$EqDistrib = (W0 + W1 + W2) / 3$$ 

A way to penalize a large variance from the equal distribution for a given container is to express it in the following way:

$$(W0 + W1 + W2 - EqDistrib)^2$$

Let's take the following example:

|              |               |
|--------------|---------------|
|Weights       | 1, 5, 9, 7, 3 |
|Total weight  |      25       |
|Containers    |    A, B, C    |
|EqualDistrib  | 25 / 3 = 8.33 |

Taking the example below, we can calculate the variance from the equal distribution for each of the given containers, shown in the rightmost column:

| Containers | 1 | 5 | 9 | 7 | 3 | Calculation | Variance |
|------------|---|---|---|---|---|-------------|----------|
| A          | 0 | 0 | 9 | 0 | 0 | (9-8.33)^2  | = 0.4489 |
| B          | 0 | 5 | 0 | 0 | 3 |(5+3-8.33)^2 | = 0.1089 |
| C          | 1 | 0 | 0 | 7 | 0 |(1+7-8.33)^2 | = 0.1089 |

As we need to represent our problem in a binary format we need to "encode" the presence ($x_i=1$) or absence ($x_i=0$) of a given container on a container. To do this, we need to have a label for the weight of each weight in each container. The table below shows how we assign this continuous index by repeating the list of container weights for each container and assigning a single list of weight labels across all three containers:

| Containers | A |     |     |     |     | B |     |     |     |     | C   |        |        |        |        |
|---|--------|-----|-----|-----|-----|--------|-----|-----|-----|-----|----------|--------|--------|--------|--------|
|Weight| 1 |  5  |  9  |  7  |  3  | 1 |  5  |  9  |  7  |  3  | 1 | 5 | 9 | 7 | 3  |
|Weight label|*w<sub>0</sub>*|*w<sub>1</sub>*|*w<sub>2</sub>*|*w<sub>3</sub>*|*w<sub>4</sub>*| *w<sub>5</sub>*|*w<sub>6</sub>*|*w<sub>7</sub>*|*w<sub>8</sub>*|*w<sub>9</sub>*|*w<sub>10</sub>*|*w<sub>11</sub>*|*w<sub>12</sub>*|*w<sub>13</sub>*|*w<sub>14</sub>*|

> Note a difference with the 2-container, Ising formulation: there, the number of weight variables is the same as the number of weights, while here it is (number of weights) x (number of containers)

The cost function $H1$ becomes:

$$ H1 = H_{A} + H_{B} + H_{C} $$

where:

$$ H_{A} = (w_0 x_0 + w_1 x_1 + w_2 x_2 + w_3 x_3 + w_4 x_4 - EqDistrib)^2 $$

$$ H_{B} = (w_5 x_5 + w_6 x_6 + w_7 x_7 + w_8 x_8 + w_9 x_9 - EqDistrib)^2 $$

and 

$$ H_{C} = (w_{10} x_{10} + w_{11} x_{11} + w_{12} x_{12} + w_{13} x_{13} + w_{14} x_{14} - EqDistrib)^2 $$
We can expand the above and group the common terms, for example if we expand $H_{A}$, we get:

$$ H_{A} = (\sum_i(w_i x_i) - EqDistrib)^2 $$
$$ = (w_0 x_0 + w_1 x_1 + w_2 x_2 + w_3 x_3 + w_4 x_4 - EqDistrib)^2 $$ 

To simplify things for the expansion, let's rename the variables as follows:

$$ w_0 x_0 = a $$
$$ w_1 x_1 = b $$
$$ w_2 x_2 = c $$
$$ w_3 x_3 = d $$
$$ w_4 x_4 = e $$
$$ EqDistrib = f $$
 

So now we have:

$$ H_{A} = (\sum_i(w_i x_i) - EqDistrib)^2 $$ 
$$ = (w_0 x_0 + w_1 x_1 + w_2 x_2 + w_3 x_3 + w_4 x_4 - EqDistrib)^2 $$
$$ = (a + b + c + d + e - f)^2$$
$$= a^2 + b^2 + c^2 + d^2 + e^2 + f^2 + 2(ab + ac + ad + ae + bc + bd + be + cd + ce + de) - 2(af + bf + cf + df + ef) $$ 

Substituting our original values back in, this gives us the following:

$$ H_{A} = (\sum_i(w_i x_i) - EqDistrib)^2 $$ 
$$ = w_0^2 x_0^2 + w_1^2 x_1^2 + w_2^2 x_2^2 + w_3^2 x_3^2 + w_4^2 x_4^2 $$
$$ + EqDistrib ^2 $$
$$ + 2(w_0 x_0 \cdot w_1 x_1 + w_0 x_0 \cdot w_2 x_2 + w_0 x_0 \cdot w_3 x_3 + w_0 x_0 \cdot w_4 x_4 + w_1 x_1 \cdot w_2 x_2 + w_1 x_1 \cdot w_3 x_3 + w_1 x_1 \cdot w_4 x_4 + w_2 x_2 \cdot w_3 x_3 + w_2 x_2 \cdot w_4 x_4 + w_3 x_3 \cdot w_4 x_4)$$
$$- 2(w_0 x_0 \cdot EqDistrib +  w_1 x_1 \cdot EqDistrib + w_2 x_2 \cdot EqDistrib + w_3 x_3 \cdot EqDistrib + w_4 x_4 \cdot EqDistrib) $$ 

We can do the same for $H_{B}$, and $H_{C}$.

## Penalize the assignment of the same container on multiple containers
Using the containers weight encoding above, we can devise a cost function such as this one for the first container:

$$ H_{D} = (w_0 x_0 + w_5 x_5 + w_{10} x_{10} - w_0)^2 $$
As $w_0$, $w_5$ and $w_{10}$ are actually the same value (it is the same container represented across multiple containers) we have: 
$$ H_{D} = (w_0 x_0 + w_0 x_5 + w_0 x_{10} - w_0)^2 $$
If we expand and group the common terms, we get the following:

$$ H_{D} = {w_0}^2 {x_0}^2 + {w_0}^2 {x_5}^2 + {w_0}^2 {x_{10}}^2 + {w_0}^2 +
2 ({w_0}^2 x_0 x_5 + {w_0}^2 x_0 x_{10} + {w_0}^2 x_5 x_{10})
- 2({w_0}^2 x_0 + {w_0}^2 x_5 + {w_0}^2 x_{10}) $$
We can then repeat the above for each container across all containers:

So in addition to:

$$ H_{D} = (w_0 x_0 + w_0 x_5 + w_0 x_{10} - w_0)^2 $$

we also have:

$$ H_{E} = (w_1 x_1 + w_1 x_6 + w_1 x_{11} - w_1)^2 $$ 
$$ H_{F} = (w_2 x_2 + w_2 x_7 + w_2 x_{12} - w_2)^2 $$
$$ H_{G} = (w_3 x_3 + w_3 x_8 + w_3 x_{13} - w_3)^2 $$
$$ H_{H} = (w_4 x_4 + w_4 x_9 + w_4 x_{14} - w_4)^2 $$
Grouping these together into a single cost function, $H2$, we get:

$$ H2 = H_{D} + H_{E} + H_{F}+ H_{G}+ H_{H} $$

which we can expand and group the terms as we did with $H_D$ above.

## Combining our cost functions

The final part of the problem definition is to combine our cost functions $H1$ and $H2$:

$$ H = H1 + H2 $$

You will notice that $H1$ and $H2$ have common indices $[i,i]/[m,m]$ and $[i]/[m]$. We will need to be careful to not duplicate them, but sum them, in our final list of terms describing the cost function.

## Package functions to solve this problem

1. First, let's define a function to add terms according to our definition of the H1 cost function, where we penalized the variance from an equal distribution between the containers: `add_terms_weight_variance_cost`
2. Next, let's incorporate our definition of the second part of our cost function, H2, where we wished to penalize the assignment of the same container on multiple containers: `add_terms_duplicate_weight_cost`
3. To reduce the number of terms, the single order terms (where $x_i$ isn't multipled by another entry in the $x$ set) are moved from the `add_terms_duplicate_weight_cost` function and combined in the `add_terms_weight_variance_cost` function.

Combining these together, we can create our cost function definition of the multi-container problem.
