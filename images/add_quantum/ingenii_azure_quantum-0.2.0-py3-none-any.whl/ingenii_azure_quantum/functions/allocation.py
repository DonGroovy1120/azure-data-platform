from azure.quantum.optimization import ProblemType, SimulatedAnnealing, \
    Solver, Term
from itertools import combinations
from typing import List

from ingenii_azure_quantum.base_classes import AzureAlgorithm

class AllocateWeightsBetweenContainers(AzureAlgorithm):

    description = "Allocate a list of weights evenly between a number of containers"
    required_parameters = {
        "weights": "The list of the weights to allocate",
        "nb_containers": "The number of containers to allocate between",
    }
    optional_parameters = {
        "problem_name": "The name of the problem for when this is submitted to the Azure Quantum Workspace",
        "solver": "The class of the solver to use from azure.quantum.optimization. By default SimulatedAnnealing",
        "**kwargs": "Any other parameters to pass to the solver",
    }
    example_parameters = {
        "weights": [3, 8, 3, 4, 1, 5, 2, 2, 7, 9, 5, 4, 8, 9, 4, 6, 8, 7, 6, 2, 2, 9, 4, 6, 3, 8, 5, 7, 2, 4, 9, 4],
        "nb_containers": 5,
    }

    @classmethod
    def __str__(cls):
        return "Ingenii Azure Quantum algorithm AllocateWeightsBetweenContainers"

    @property
    def weights(self):
        return self._weights

    @weights.setter
    def weights(self, value: List[int]):
        self._weights = value
        self.generate_terms()

    @property
    def nb_containers(self):
        return self._nb_containers

    @nb_containers.setter
    def nb_containers(self, value: int):
        self._nb_containers = value
        
        # Must be in this order
        self.set_problem_type()
        self.generate_terms()

    def __init__(
            self, weights: List[int], nb_containers: int,
            problem_name: str = "",
            solver: Solver = SimulatedAnnealing,
            **kwargs,
        ):
        super().__init__()
    
        self._weights = None
        self._nb_containers = None

        self.weights = weights
        self.nb_containers = nb_containers

        if problem_name:
            self.problem_name = problem_name

        self.solver = solver
        self.solver_parameters = kwargs

    def _add_terms_weight_variance_cost(self) -> List[Term]:
        """ Add to the cost function Terms to minimise the weight variance
        between the containers """
        target_weight = sum(self.weights) / self.nb_containers
        nb_weights = len(self.weights)

        # Treat weights in this format:
        # 1  5  9  7  3  - 1  5  9  7  3  - 1   5   9   7   3
        # W0 W1 W2 W3 W4   W5 W6 W7 W8 W9   W10 W11 W12 W13 W14 

        return [
            term
            for i in range(self.nb_containers)
            for j, w in enumerate(self.weights, start=i*nb_weights)
            for term in (
                # -1*Wi*target_weight.xi -2Wi^2.xi (weight variance cost + duplicate weight cost)
                Term(w=-2*w*target_weight - 2*w*w, indices=[j]),
                # Wi^3.xi^2 + Wi^2.xi^2 (weight variance cost + duplicate weight cost)
                Term(w=2*w*w, indices=[j, j])
            )
        ] + [
            Term(
                w=2*self.weights[c[0]]*self.weights[c[1]],
                indices=[i*nb_weights + c[0], i*nb_weights + c[1]]
            ) # 2*Wi*Wj (weight variance cost)
            for i in range(self.nb_containers)
            for c in combinations(range(nb_weights), 2)
        ]

    def _add_terms_duplicate_weight_cost(self) -> List[Term]:
        """ Add to the cost function Terms to avoid allocating the same weight
        to different containers"""
        # The following is integrated into add_terms_weight_variance_cost to reduce
        # the number of Terms and speed-up Terms generation
        # for c in combinations(range(start, end+1), 1):
        #     w = container_weights[c[0]][0]
        #     i1 = container_weights[c[0]][1]
        #     terms.append(Term(w=w*w, indices=[i1,i1]))              # Wi^2

        # 2.w^2.x_i.x_j terms

        # The following is integrated into add_terms_weight_variance_cost to reduce
        # the number of Terms and speed-up Terms generation
        # # for c in combinations(range(start, end+1), 1):
        #     w = container_weights[c[0]][0]
        #     i1 = container_weights[c[0]][1]
        #     terms.append(Term(w=-2*w*w, indices=[i1]))              # -2*Wi^2

        nb_weights = len(self.weights)

        return [
            # Treat weights in this format:
            # 1  1  1 - 5  5  5 - 9  9  9 - 7  7  7 - 3  3  3
            # W0 W5 W10 W1 W6 W11 W2 W7 W12 W3 W8 W13 W4 W9 W14
            Term(
                w=2*self.weights[i]*self.weights[i],
                indices=[i + c[0]*nb_weights, i + c[1]*nb_weights]
            ) # Term(w=2*Wm^2, [m,n])
            for i in range(nb_weights)
            for c in combinations(range(self.nb_containers), 2)
        ] + [
            Term(w=weight*weight, indices=[]) # w^2 term
            for weight in self.weights
        ]

    def generate_terms(self):
        """ Create the Terms for the cost function to allocate the weights """

        if self.weights is None or self.nb_containers is None:
            return

        if self.problem_type == ProblemType.ising:
            # Terms are symmetrical, so only pass the minimum required
            self.terms = [
                Term(c = w_i * w_j, indices = [i, j])
                for i, w_i in enumerate(self.weights)
                for j, w_j in enumerate(self.weights[i+1:], start=i+1)
            ]

        # PUBO problem
        self.terms = \
            self._add_terms_weight_variance_cost() + \
            self._add_terms_duplicate_weight_cost()

    def set_problem_type(self):
        """ Determine the problem type, which will affect the Terms generated """
        if self.nb_containers == 2:
            self.problem_type = ProblemType.ising
        else:
            self.problem_type = ProblemType.pubo

    def parse_allocations(self):
        """
        Parse the result of the allocation, adding objects to more easily use it
        container_to_weight_id: dictionary where the key is the container ID, and
            value is a list of the indexes of the weights allocated to it
        container_to_weight: As above, but the values are a list of the weight
            values themselves instead of the indexes
        """
        nb_weights = len(self.weights)
        container_to_weight_id = self.result["container_to_weight_id"] = {
            i: [] for i in range(self.nb_containers)
        }
        container_to_weight = self.result["container_to_weight"] = {
            i: [] for i in range(self.nb_containers)
        }

        if not self.result.get("configuration"):
            return

        for key, alloc in self.result["configuration"].items():
            key = int(key)

            if self.problem_type in (ProblemType.ising, ProblemType.ising_grouped):
                # 1 is allocated to the first container, -1 to the second
                container_id = {1: 0, -1: 1}[alloc]
                container_to_weight_id[container_id].append(key)
                container_to_weight[container_id].append(self.weights[key])
            else:
                if alloc != 1:
                    continue
                container_id = key // nb_weights
                weight_id = key % nb_weights
                container_to_weight_id[container_id].append(weight_id)
                container_to_weight[container_id].append(self.weights[weight_id])

    def visualize_allocation_result(self):
        """ Given the parsed result, print some useful information """

        if self.result.get("configuration"):
            for i in sorted(self.result["container_to_weight_id"].keys()):
                print(
                    f"Container {i}: " +
                    "\t" + str(self.result["container_to_weight_id"][i]) + " - " +
                    str(sum(self.result["container_to_weight"][i]))
                )
        else:
            print("No Configuration")
        
        if "cost" in self.result:
            print(f"Cost: {self.result['cost']}")
        else:
            print("No Cost")

        if "parameters" in self.result:
            print(f"Parameters: {self.result['parameters']}")
        else:
            print("No Parameter")

    def run(self):
        if self.verbose:
            print("Total Weight:", sum(self.weights))
            print("Equal weight distribution:", sum(self.weights) / self.nb_containers)

        if self.problem_name:
            problem_name = self.problem_name
        else:
            problem_name = \
                f"Allocating {str(len(self.weights))} weights between " \
                f"{str(self.nb_containers)} containers ({len(self.terms):,} terms)"

        self._submit(problem_name=problem_name)

        # Update the results object with the allocations
        self.parse_allocations()
