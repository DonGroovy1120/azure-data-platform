from azure.quantum.optimization import ProblemType, SimulatedAnnealing, \
    Solver, Term
from typing import List

from ingenii_azure_quantum.base_classes import AzureAlgorithm

class TravelingSalesman(AzureAlgorithm):

    description = ""
    required_parameters = {
        "cost_matrix": "list[list[int]]. The matrix of costs between each of the points. Each sub-lists corresponds to one origin node",
    }
    optional_parameters = {
        "traveling_cost_weight": "float, by default 1. Penalty weight for the cost of traveling between nodes",
        "single_node_weight": "float, by default 2. Constraint weight for the salesman can be at only one node at a time",
        "salesman_somewhere_weight": "float, by default 1.65. Constraint weight for the salesman must be somewhere",
        "same_node_twice_weight": "float, by default 2. Penalty weight for the salesman must not visit the same node twice",
        "end_at_starting_node_weight": "float, by default 10. Penalty weight that the salesman must start and end at the same node",
        "problem_name": "The name of the problem for when this is submitted to the Azure Quantum Workspace",
        "solver": "The class of the solver to use from azure.quantum.optimization. By default SimulatedAnnealing",
        "**kwargs": "Any other parameters to pass to the solver",
    }
    example_parameters = {
        "cost_matrix": [
            [1, 4, 7, 4, 3],
            [3, 3, 3, 1, 2],
            [2, 5, 2, 3, 1],
            [7, 8, 1, 3, 5],
            [3, 2, 1, 9, 8]
        ]
    }

    _cost_matrix = None

    @property
    def cost_matrix(self):
        return self._cost_matrix

    @cost_matrix.setter
    def cost_matrix(self, matrix: List[List[int]]):
        self._cost_matrix = matrix
        self.nb_nodes = len(matrix)

        max_cost = 0
        for node_costs in matrix:
            for each_cost in node_costs:
                if each_cost > max_cost:
                    max_cost = each_cost
        
        self.max_cost = max_cost
    
    @property
    def nb_nodes(self):
        return self._nb_nodes

    @nb_nodes.setter
    def nb_nodes(self, value: List[List[int]]):
        self._nb_nodes = value
    
    @property
    def max_cost(self):
        return self._max_cost

    @max_cost.setter
    def max_cost(self, value: List[List[int]]):
        self._max_cost = value
    
    _traveling_cost_weight = None

    @property
    def traveling_cost_weight(self):
        return self._traveling_cost_weight

    @traveling_cost_weight.setter
    def traveling_cost_weight(self, value: float):
        self._traveling_cost_weight = value

    _single_node_weight = None

    @property
    def single_node_weight(self):
        return self._single_node_weight

    @single_node_weight.setter
    def single_node_weight(self, value: float):
        self._single_node_weight = value

    _salesman_somewhere_weight = None

    @property
    def salesman_somewhere_weight(self):
        return self._salesman_somewhere_weight

    @salesman_somewhere_weight.setter
    def salesman_somewhere_weight(self, value: float):
        self._salesman_somewhere_weight = value

    _same_node_twice_weight = None

    @property
    def same_node_twice_weight(self):
        return self._same_node_twice_weight

    @same_node_twice_weight.setter
    def same_node_twice_weight(self, value: float):
        self._same_node_twice_weight = value

    _end_at_starting_node_weight = None

    @property
    def end_at_starting_node_weight(self):
        return self._end_at_starting_node_weight

    @end_at_starting_node_weight.setter
    def end_at_starting_node_weight(self, value: float):
        self._end_at_starting_node_weight = value

    problem_type = ProblemType.pubo

    def __str__(self):
        return "Ingenii Azure Quantum algorithm TravelingSalesman"

    def __init__(
            self, cost_matrix: List[List[int]],
            traveling_cost_weight: float=1,
            single_node_weight: float=2,
            salesman_somewhere_weight: float=1.65,
            same_node_twice_weight: float=2,
            end_at_starting_node_weight: float=10,
            problem_name: str = "",
            solver: Solver = SimulatedAnnealing,
            **kwargs,
        ):
        super().__init__()

        self.cost_matrix = cost_matrix

        self.traveling_cost_weight = traveling_cost_weight
        self.single_node_weight = single_node_weight
        self.salesman_somewhere_weight = salesman_somewhere_weight
        self.same_node_twice_weight = same_node_twice_weight
        self.end_at_starting_node_weight = end_at_starting_node_weight

        if problem_name:
            self.problem_name = problem_name

        self.solver = solver
        self.solver_parameters = kwargs

    def generate_terms(self):
        """ Create the terms for the solver to use """

        self.nb_nodes

        # Terms will contain the weighting terms for the trips
        self.terms = [
            ##### Cost of traveling between nodes
            # Assign a weight to every possible trip from node i to node j for each trip 
            # 'traveling_cost_weight' allows us to tune the weights between the penalties 
            Term(
                c = self.traveling_cost_weight * self.cost_matrix[i][j], # Element of the cost matrix
                indices = [i + (self.nb_nodes * k), j + (self.nb_nodes * (k + 1))] # +1 to denote dependence on next location
            )
            for k in range(self.nb_nodes) # For each trip
            for i in range(self.nb_nodes) # For each origin node
            for j in range(self.nb_nodes) # For each destination node
        ] + [
            ##### Constraint: Location constraint - salesperson can only be at 1 node at a time.
            # 'single_node_weight' allows us to tune the weights between the penalties 
            Term(
                c = int(self.single_node_weight * self.max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
                indices = [i + self.nb_nodes * l, j + self.nb_nodes * l]
            )
            for l in range(self.nb_nodes + 1) # The total number of nodes that are visited over the route (+1 because returning to starting node)
            for i in range(self.nb_nodes) # For each origin node
            for j in range(self.nb_nodes) # For each destination node
            if i < j # i<j because we don't want to penalize twice // i==j is forbidden (above)
        ] + [
            ##### Constraint: Location constraint - encourage the salesperson to be 'somewhere' otherwise all x_k might be 0 (for example).
            # 'salesman_somewhere_weight' allows us to tune the weights between the penalties 
            Term(
                c = int(-1 * self.salesman_somewhere_weight * self.max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
                indices = [v]   
            )
            for v in range((self.nb_nodes + 1) * self.nb_nodes) # Select variable (v represents a node before/after any trip)
        ] + [
            ##### Penalty for traveling to the same node again --- (in the last step we can travel without penalties (this is to make it easier to specify an end node =) ))
            # 'same_node_twice_weight' allows us to tune the weights between the penalties 
            Term(
                c = int(self.same_node_twice_weight * self.max_cost), # assign a weight penalty dependent on maximum distance from the cost matrix elements
                indices = [p, f]   
            )
            for p in range((self.nb_nodes + 1) * self.nb_nodes) # This selects a present node x: 'p' for present    
            for f in range(p + self.nb_nodes, self.nb_nodes * (self.nb_nodes), self.nb_nodes) # This selects the same node x but after upcoming trips: 'f' for future
        ] + [
            ##### Begin at x0
            # 'end_at_starting_node_weight' allows us to tune the weights between the penalties 
            Term(
                c = int(-1 * self.end_at_starting_node_weight * self.max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
                indices = [0]   
            ), 
            ##### End at x0
            Term(
                c = int(-1 * self.end_at_starting_node_weight * self.max_cost), # Assign a weight penalty dependent on maximum distance from the cost matrix elements
                indices = [self.nb_nodes * self.nb_nodes]   
            ) 
        ]

    def parse_path(self):
        """ Parse the result found, adding to the 'result' dictionary a more
        easily understood 'path_route' object, and the 'cost' of the result """

         ##### Read the results returned by the solver - need to make the solution readable
        ##### Read the return result (dictionary) from the solver and sort it
        parsed_config = sorted([int(k) for k, v in self.result["configuration"].items() if v == 1])

        ##### Create the route
        path_route = self.result["path_route"] = [
            {
                "node_id": node_index % self.nb_nodes,
                "time_step": node_index // self.nb_nodes,
            }
            for node_index in parsed_config
        ]

        ###### Calculate the total cost of the route the salesperson made (can be in time (minutes) or in distance (km))
        self.result["cost"] = sum([
            self.cost_matrix[node1["node_id"]][node2["node_id"]]
            for node1, node2 in zip(path_route[:-1], path_route[1:])
        ])

    def validate_path(self):
        """ Validate that the produced path is valid """
        ##### Check whether the solution satisfies the optimization constraints
        path_route = self.result["path_route"]

        is_valid = True
        errors = []

        ##### Check if the number of travels is equal to the number of nodes + 1 (for returning home)
        if len(path_route) != self.nb_nodes + 1:
            errors.append("This solution is not valid - Number of nodes visited invalid!")
            is_valid = False

        ##### Check if the nodes are different (except start/end node)
        past_nodes = set()
        for node in path_route[:-1]: # Start to second last node must all be different - skip last node so - 1
            if node["node_id"] in past_nodes:
                errors.append("This solution is not valid - Traveled to a non-starting node more than once")
                is_valid = False
            past_nodes.add(node["node_id"])

        ##### Check if the end node is same as the start node
        if path_route[0]["node_id"] != path_route[-1]["node_id"]:
            errors.append(
                f"This solution is not valid - Start node "
                f"{path_route[0]['node_id']} is not equal to end node "
                f"{path_route[-1]['node_id']}"
            )
            is_valid = False

        if errors:
            for error in errors:
                print(error)
        else:
            print("This solution is valid")
        
        self.result["valid"] = is_valid
        self.result["errors"] = errors

    def run(self):
        """ From the cost matrix, find a suitable route """

        if self.problem_name:
            problem_name = self.problem_name
        else:
            problem_name = \
                f"Traveling salesperson problem for {self.nb_nodes}x{self.nb_nodes} matrix, " \
                f"max cost {self.max_cost} ({len(self.terms):,} terms)"\

        # Submit the problem and wait for the result
        self._submit(problem_name=problem_name)

        # Return the simulation result in a human understandable way
        self.parse_path()

        # Validate the result
        self.validate_path()
