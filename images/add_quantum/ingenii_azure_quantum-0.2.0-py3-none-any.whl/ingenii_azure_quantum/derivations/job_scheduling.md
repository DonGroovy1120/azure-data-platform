# Job Shop Scheduling Sample

## Introduction
Job shop scheduling is a common and important problem in many industries. For example, in the automobile industry manufacturing a car involves many different types of operations which are performed by a number of specialized machines - optimizing the production line to minimize manufacturing time can make for significant cost savings. 

The job shop scheduling problem is defined as follows: you have a set of jobs ($J_0, J_1, J_2, \dots, J_{a-1} \text{, where } a \text{ is the total number of jobs}$), which have various processing times and need to be processed using a set of machines ($m_0, m_1, m_2, \dots, m_{b-1}\text{, where } b \text{ is the total number of machines}$). The goal is to complete all jobs in the shortest time possible, called minimizing the **makespan**.

Each job consists of a set of operations, and the operations must be performed in the correct order to complete that job.

In this sample, we'll introduce the necessary concepts and tools for describing this problem in terms of a penalty model, so we can create the Terms to submit the problem to the Azure Quantum Optimization service.

Imagine, for example, that you have a to-do list. Each item on the list is a **job** using this new terminology. Each job in this list consists of a set of operations, and each operation has a processing time. You also have some tools at hand that you can use to complete these jobs (the **machines**).

TODOs:

- Pay electricity bill
  1. Log in to site (*2 minutes*) - **computer**
  2. Pay bill (*1 minute*) - **computer**
  3. Print receipt (*3 minutes*) - **printer**
  

- Plan camping trip
  1. Pick campsite (*2 minutes*) - **computer**
  2. Pay online (*2 minutes*) - **computer**
  3. Print receipt (*3 minutes*) - **printer**
  

- Book dentist appointment
  1. Choose time (*1 minute*) - **computer**
  2. Pay online (*2 minutes*) - **computer**
  3. Print receipt (*3 minutes*) - **printer**
  4. Guiltily floss your teeth (*2 minutes*)  - **tooth floss**

But there are some constraints:

1. Each of the tasks (**operations**) in a todo (**job**) must take place in order. You can't print the receipt before you have made the payment! This is called a **precedence constraint**.
2. You start an operation only once, and once started it must be completed before you do anything else. There's no time for procrastination! This is called the **operation-once constraint**.
3. Each tool (**machine**) can only do one thing at a time. You can't simultaneously print two receipts unless you invest in multiple printers. This is the **no-overlap constraint**.

The rest of this derivation will be spent constructing what is known as a **cost function**, which is used to represent the problem. This cost function is what will be submitted to the Azure Quantum Optimization solver, in the form of an array of `Term` objects, representing the problem constraints.

Each solution configuration is a particular assignment of starting times for the operations you are looking to schedule. The goal of the optimization is to minimize the cost of the solution - in this case to minimize the amount of time taken to complete all operations.

## Problem formulation

The first step is to take the constraints identified above and formulate them as mathematical equations from which we can determine the `Term` objects.

Let's stick with the previous example of the todo list:

- $J_{0}$: Pay electricity bill
  - $O_{0}$: Log in to site (*2 minutes*) - **computer**
  - $O_{1}$: Pay bill (*1 minute*) - **computer**
  - $O_{2}$: Print receipt (*3 minutes*) - **printer**
  

- $J_{1}$: Plan camping trip
  - $O_{3}$: Pick campsite (*2 minutes*) - **computer**
  - $O_{4}$: Pay online (*2 minutes*) - **computer**
  - $O_{5}$: Print receipt (*3 minutes*) - **printer**
  

- $J_{2}$: Book dentist appointment
  - $O_{6}$: Choose time (*1 minute*) - **computer**
  - $O_{7}$: Pay online (*2 minutes*) - **computer**
  - $O_{8}$: Print receipt (*3 minutes*) - **printer**
  - $O_{9}$: Guiltily floss your teeth (*2 minutes*) - **tooth floss**

The jobs have been labeled as $J$ and assigned index numbers $0$, $1$ and $2$, to represent each of the three tasks. The operations that make up each job have also been defined, and are represented by the letter $O$.

To make it easier to code up later, all operations are identified with a continuous index number rather than, for example, starting from $0$ for each job. We can keep track of operations by their ID numbers in the code, schedule them according to the constraints and machine availability, and then tie them back to their jobs later on using the reference.

Below, you see how these definitions combine to give us a mathematical formulation for the jobs:

$$ J_{0} = \{O_{0}, O_{1}, O_{2}\} $$
$$ J_{1} = \{O_{3}, O_{4}, O_{5}\} $$
$$ J_{2} = \{O_{6}, O_{7}, O_{8}, O_{9}\} $$

**More generally:**

$$ J_{0} = \{O_{0}, O_{1}, \ldots , O_{k_{0}-1}\} \text{, where } k_{0} = n_{0} \text{, the number of operations in job } J_{0} $$
$$ J_{1} = \{O_{k_{0}}, O_{k_{0}+1}, \ldots , O_{k_{1}-1}\} \text{, where } k_{1} = n_{0} + n_{1} \text{, the number of operations in jobs } J_{0} \text{ and } J_{1} \text{ combined} $$
$$ \vdots $$
$$ J_{n-1} = \{O_{k_{n-2}}, O_{k_{n-2}+1}, \ldots , O_{k_{n-1}-1}\} \text{, where } k_{n-1} = \text{ the total number of operations across all jobs } $$ 

The next piece of notation is a binary variable, which will be called $x_{i, t}$. We use this variable to represent whether an operation starts at time $t$ or not:

$$ \text{If } x_{i,t} = 1, \text{ } O_i\text{ starts at time } \textit{t} $$
$$ \text{If } x_{i,t} = 0, \text{ } O_i\text{ does not start at time } \textit{t} $$

Because $x_{i, t}$ can take the value of either $0$ or $1$, this is known as a binary optimization problem. More generally, this is called a polynomial unconstrained binary optimization (or PUBO) problem. You may also see these PUBO problems referred to as Higher Order Binomial Optimization (HOBO) problems - these terms both refer to the same thing.

$t$ is used to represent the time. It goes from time $0$ to $T - 1$ in integer steps. $T$ is the latest time an operation can be scheduled:

$$0 \leq t < T$$

Lastly, $p_{i}$ is defined to be the processing time for operation $i$ - the amount of time it takes for operation $i$ ($O_{i}$) to complete:

$$\text{If } O_{i} \text{ starts at time } \textit{t} \text{, it will finish at time } t + p_{i}$$
$$\text{If } O_{i+1} \text{ starts at time } \textit{s} \text{, it will finish at time } s + p_{i+1}$$

Now that the terms have been defined, we can formulate the problem.

The first step is to represent the constraints mathematically. This will be done using a penalty model - every time the optimizer explores a solution that violates one or more constraints, we give that solution a penalty:

| Constraint | Penalty condition |
|---|---|
|**Precedence constraint**<br>Operations in a job must take place in order.|Assign penalty every time $O_{i+1}$ starts before $O_{i}$ has finished (they start out of order).|
|**Operation-once constraint**<br>Each operation is started once and only once.|Assign penalty if an operation isn't scheduled within the allowed time.<br>**Assumption:** if an operation starts, it runs to completion.|
|**No-overlap constraint**<br>Machines can only do one thing at a time.|Assign penalty every time two operations on a single machine are scheduled to run at the same time.|

We will also define an objective function, which will minimize the time taken to complete all operations (the **makespan**).

> As you will see during the exploration of the cost function and its constituent penalty terms, the overall cost function is quadratic (because the highest order polynomial term you have is squared). This makes this problem a **Quadratic Unconstrained Binary Optimization (QUBO)** problem, which is a specific subset of **Polynomial Unconstrained Binary Optimization (PUBO)** problems (which allow for higher-order polynomial terms than quadratic). 

## Expressing the cost function

As introduced above, the binary variables which are being optimized are the operation starting times $x_{i,t}$. Instead of using two separate indices as in the mathematical formulation, we will need to define a singly-indexed binary variable $x_{i \cdot T + t}$, as we need to generate an array of `Term` objects. Given time steps $t \in [0, T-1]$, every operation $i$ contributes $T$ indices. The operation starts at the value of $t$ for which $x_{i \cdot T + t}$ equals 1.

Ultimately, any polynomial cost function can be written as a simple sum of products. That is, the function can be rewritten to have the following form, where $p_k$ indicates a product over the problem variables $x_0, x_1, \dots$:

$$ H(x) = \sum_k \alpha_k \cdot p_k(x_0, x_1, \dots) $$

$$ \text{e.g. } H(x) = 5 \cdot (x_0) + 2 \cdot (x_1 \cdot x_2) - 3 \cdot ({x_3}^2) $$

In this form, every term in the sum has a coefficient $\alpha_k$ and a product $p_k$. Each term in the sum is represented by a `Term` object, with parameters `c` - corresponding to the coefficient, and `indices` - corresponding to the product. Specifically, the `indices` parameter is populated with the indices of all variables appearing in the term. For instance, the term $2 \cdot (x_1 \cdot x_2)$ translates to the following object: `Term(c=2, indices=[1,2])`.

More generally, `Term` objects take on the following form:

```python
Term(c: float, indices: []) # Constant terms like +1
Term(c: float, indices: [int]) # Linear terms like x
Term(c: float, indices: [int, int]) # Quadratic terms like x^2 or xy
```

If there were higher order terms (cubed, for example), you would just add more elements to the indices array, like so:

```python
Term(c: float, indices: [int, int, int, ...])
```
## Defining problem parameters in code

Now that we've defined the problem parameters mathematically, we transform this information to code. In the next sections, we will construct mathematical representations of the penalty terms and use these to build the cost function, which will be of the format:

$$H(x) = \alpha \cdot f(x) + \beta \cdot g(x) + \gamma \cdot h(x) + \delta \cdot k(x) $$

where:

$$f(x) \text{, } g(x) \text{ and } h(x) \text{ represent the penalty functions.}$$
$$k(x) \text{ represents the objective function.}$$
$$\alpha, \beta, \gamma \text{ and } \delta \text{ represent the different weights assigned to the penalties.}$$

The weights represent how important each penalty function is, relative to all the others.

## Precedence constraint

The precedence constraint is defined as follows:

| Constraint | Penalty condition |
|---|---|
|**Precedence constraint**<br>Operations in a job must take place in order.|Assign penalty every time $O_{i+1}$ starts before $O_{i}$ has finished (they start out of order).|

### Worked Example

Let's take job 1 ($J_{1}$) as an example:

- $J_{1}$: Plan camping trip
  - $O_{3}$: Pick campsite (*2 minutes*)
  - $O_{4}$: Pay online (*2 minutes*)
  - $O_{5}$: Print receipt (*3 minutes*)

Let's formulate the penalty conditions for $O_{3}$ and $O_{4}$: we want to add a penalty if $O_{4}$ starts before $O_{3}$ finishes. First, we'll define our terms and set some of their values:

$$\text{Total simulation time } T = 4$$
$$O_{3} \text{ processing time: } p_{3} = 2$$
$$O_{3} \text{ starts at time } \textit{t} \text{, and finishes at time } t+p_{3}$$

$$O_{3} \text{ starts at any time } 0 \leq t < T $$
$$O_{4} \text{ can start at time } s \geq t + p_{3} $$

$O_{3}$’s finishing time is given by adding its processing time $p_{3}$ (which we’ve set to be 2) to its start time $t$. You can see the start and end times for $O_{3}$ in the table below:

| $t$ | $t = p_{3}$|
|---|---|
|0|2|
|1|3|
|2|4|

To avoid violating this constraint, the start time of $O_{4}$ (denoted by $s$) must be greater than or equal to the end time of $O_{3}$, like we see in the next column:

| $t$ | $t = p_{3}$|$s \geq t+p_{3}$|
|---|---|---|
|0|2|2, 3, 4|
|1|3|3, 4|
|2|4|4|
||**Valid configuration?**|✔|

The ✔ means that any $s$ value in this column is valid, as it doesn't violate the precedence constraint.

Conversely, if $s$ is less than $t + p_{3}$ (meaning $O_{4}$ starts before $O_{3}$ finishes), you need to add a penalty. Invalid $s$ values for this example are shown in the rightmost column:

| $t$ | $t = p_{3}$|$s \geq t+p_{3}$|$s < t+p_{3}$|
|---|---|---|---|
|0|2|2, 3, 4|0, 1|
|1|3|3, 4|0, 1, 2|
|2|4|4|0, 1, 2, 3|
||**Valid configuration?**|✔|✘|

### Penalty Formulation

This is formulated as a penalty by counting every time consecutive operations $O_{i}$ and $O_{i + 1}$ in a job take place out of order.
  
As we saw above: for an operation $O_{i}$, if the start time of $O_{i + 1}$ (denoted by $s$) is less than the start time of $O_{i}$ (denoted by $t$) plus its processing time $p_{i}$, then that counts as a penalty. Mathematically, this penalty condition looks like: $s < t + p_{i}$.

Sum that penalty over all the operations of a job ($J_{n}$) for all the jobs:
$$f(x) = \sum_{k_{n-1} \leq i < k_n, s < t + p_{i}}x_{i,t}\cdot x_{i+1,s} \text{ for each job } \textit{n}.$$

Let's break that down:

- $k_{n-1} \leq i < k_{n}$

  This means to sum over all operations for a single job.


- $s < t + p_{i}$

  This is the penalty condition - any operation that satisfies this condition is in violation of the precedence constraint.
  

- $x_{i, t}\cdot x_{i+1, s}$
  
  This represents the table in the example above, where $t$ is allowed to vary from $0 \rightarrow T - 1$, and we assign a penalty whenever the constraint is violated (when $s < t + p_{i}$).
  
  This translates to a nested `for` loop: the outer loop has limits $0 \leq t < T$ and the inner loop has limits $0 \leq s < t + p_{i}$

### Code

Using the mathematical formulation and the breakdown above, we can now translate this constraint function to code in the `precedence_constraint` function, reproduced below. You will see the `weight` argument included in this code snippet - this will be assigned a value when the function is called:

```python
terms = [
    Term(c=weight, indices=[op1*max_time+t, op2*max_time+s])
    # Loop through all jobs:
    for ops in jobs_ops_map.values()
    # Loop through all pairs of operations in this job:
    for op1, op2 in zip(ops, ops[1:])
    for t in range(0, max_time)
    # Loop over times that would violate the constraint:
    for s in range(0, min(t + processing_time[op1], max_time))
]
```

## Operation-once constraint

The operation-once constraint is defined as follows:

| Constraint | Penalty condition |
|---|---|
|**Operation-once constraint**<br>Each operation is started once and only once.|Assign penalty if an operation isn't scheduled within the allowed time.<br>**Assumption:** if an operation starts, it runs to completion.|

#### Worked Example

We will again take job 1 ($J_{1}$) as an example:

- $J_{1}$: Plan camping trip
  - $O_{3}$: Pick campsite (*2 minutes*)
  - $O_{4}$: Pay online (*2 minutes*)
  - $O_{5}$: Print receipt (*3 minutes*)

Recall the variable $x_{i,t}$:

$$ \text{If } x_{i,t} = 1, \text{ } O_i\text{ starts at time } \textit{t} $$
$$ \text{If } x_{i,t} = 0, \text{ } O_i\text{ does not start at time } \textit{t} $$

According to this constraint, $x_{i,t}$ for a specific operation should equal 1 **once and only once** from $t = 0 \rightarrow T - 1$ (because it should start once and only once during the allowed time). So, we need to assign a penalty if the sum of $x_{i,t}$ for each operation across all allowed times doesn’t equal exactly 1.

Let’s take $O_{3}$ as an example again:

|$t$|$x_{3,t}$|$x_{3,t}$|$x_{3,t}$|
|---|---|---|---|
|0|0|0|0|
|1|1|1|0|
|2|0|1|0|
|$\sum_t {x_{3,t}} =$|1|2|0|
|**Valid configuration?**|✔|✘|✘|

In the first configuration, we see that $O_{3}$ starts at time 1 and no other time ($x_{3,t} = 1$ at time $t = 1$ and is $0$ otherwise). The sum of $x_{i,t}$ values over all $t$ for this example is 1, therefore this is a valid solution.

In the second approach $O_{3}$ has been scheduled to start at both time 1 and time 2, so the sum of $x_{i,t}$ values over all $t$ is now greater than 1. This violates the constraint and thus we must apply a penalty.

In the thrid approach, none of the $x_{3,t}$ values equal 1 for any time in the simulation, meaning the operation is never scheduled. This means that the sum of $x_{3,t}$ values over all $t$ is 0 - the constraint is once again violated and we must allocate a penalty.

### Penalty Formulation

As seen previously, we want to assign a penalty whenever the sum of $x_{i,t}$ values across all possible $t$ values is not equal to 1. This is how we represent that mathematically:

$$g(x) = \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2.$$

Let's break that down:

- $\left(\sum_{0\leq t < T} x_{i,t}\right) - 1$

  As we saw in the sum row of the tables in the worked example, $\sum_{0\leq t < T} x_{i,t}$ should always equal exactly 1 (meaning that an operation must be scheduled **once and only once** during the allowed time). This means that $\left(\sum_{0\leq t < T} x_{i,t}\right) - 1$ should always give 0. This means there is no penalty assigned when the constraint is not violated.
  
  In the case where $\sum_{0\leq t < T} x_{i,t} > 1$ (meaning an operation is scheduled to start more than once, like in the second example above), we now have a positive, non-zero penalty term as $\left(\sum_{0\leq t < T} x_{i,t}\right) - 1 > 0$.
  
  In the case where $\sum_{0\leq t < T} x_{i,t} = 0$ (meaning an operation is never scheduled to start, like in the last example above), we now have a $-1$ penalty term as $\left(\sum_{0\leq t < T} x_{i,t}\right) - 1 = 0 - 1 = -1$.

- $\left(\sum\dots\right)^2$

  Because the penalty terms must always be positive (otherwise we would be *reducing* the penalty when an operation isn't scheduled), we must square the result of $\left(\sum_{0\leq t < T} x_{i,t}\right) - 1$.
  
  This ensures that the penalty term is always positive (as $(-1)^2 = 1$).

- $\sum_{i} \left((\dots)^2\right)$

  Lastly, we must sum all penalties accumulated across all operations $O_{i}$ from all jobs.
  
To translate this constraint to code form, we are going to need to expand the quadratic equation in the sum. To do this, Let's once again take $O_{3}$ as an example. Let's set $T = 2$ so the $t$ values will be 0 and 1. The first step will be to substitute in these values:

$$ \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2 = \left(x_{3,0} + x_{3,1} - 1\right)^2 $$

For simplicity, the $x_{3,t}$ variables will be renamed as follows: 

$$ x_{3,0} = x $$
$$ x_{3,1} = y $$

Substituting these values in, you now have the following:

$$ \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2 = \left(x_{3,0} + x_{3,1} - 1\right)^2 $$
$$ =\left(x + y - 1\right)^2 $$

Next, you need to expand out the bracket and multiply each term in the first bracket with all terms in the other bracket:

$$ \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2 = \left(x_{3,0} + x_{3,1} - 1\right)^2 $$
$$ = \left(x + y - 1\right)^2 $$
$$ = (x + y - 1)\cdot(x + y - 1) $$
$$ = x^2 + y^2 + 2xy - 2x - 2y + 1 $$

The final step simplifies things a little. Because this is a binary optimization problem, $x$ and $y$ can only take the values of $0$ or $1$. Because of this, the following holds true:

$$\begin{array}{ccc}
x^2 = x & and & y^2 = y \\
\end{array}$$
as
$$\begin{array}{ccc}
0^2 = 0 & and & 1^2 = 1
\end{array}$$

This means that the quadratic terms in the penalty function can combine with the two linear terms, giving the following formulation of the penalty function:
$$ \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2 = x^2 + y^2 + 2xy - 2x - 2y + 1 $$
$$ = x + y + 2xy - 2x - 2y + 1 $$
$$ = 2xy - x - y + 1 $$

If $T$ was larger, there would be more terms ($z$ and so on, for example). These expand to similar terms.

### Code

We use this expanded version of the penalty function to build the penalty terms in the `operation_once_constraint` function, reproduced below. Again, the `weight` argument is included, to be assigned a value when the function is called.

```python
terms = [
    # 2xy - x - y parts of the constraint function
    term
    # Loop through all operations
    for op in ops_jobs_map.keys()
    for t in range(max_time)
    for term in [
        # - x - y terms
        Term(c=weight*-1, indices=[op*max_time + t])
    ] + [
        Term(c=weight*2, indices=[op*max_time + t, op*max_time + s])
        # + 2xy term
        # Loop through all other start times for the same job to get the cross terms
        for s in range(t + 1, max_time)
    ]
] + [
    # + 1 term
    Term(c=weight*1, indices=[])
]
``` 

### No-overlap constraint

The no-overlap constraint is defined as follows:

| Constraint | Penalty condition |
|---|---|
|**No-overlap constraint**<br>Machines can only do one thing at a time.|Assign penalty every time two operations on a single machine are scheduled to run at the same time.|

#### Worked Example

For this final constraint, $J_{1}$ will once again be used as an example:

- $J_{1}$: Plan camping trip
  - $O_{3}$: Pick campsite (*2 minutes*) - **computer**
  - $O_{4}$: Pay online (*2 minutes*) - **computer**
  - $O_{5}$: Print receipt (*3 minutes*) - **printer**

Recall once more the variable $x_{i,t}$:

$$ \text{If } x_{i,t} = 1, \text{ } O_i\text{ starts at time } \textit{t} $$
$$ \text{If } x_{i,t} = 0, \text{ } O_i\text{ does not start at time } \textit{t} $$

As we can see from the above, $O_{3}$ and $O_{4}$ must be completed using the same machine (the computer). We can't do two things at the same time using the same machine, so to avoid violating the no-overlap constraint, we ensure that $O_{3}$ and $O_{4}$ begin at different times: in other words, $x_{3,t}$ and $x_{4,t}$ must not equal 1 at the same time. We must also make sure that the operations don't overlap, just like you saw in the precedence constraint. This means that if $O_{3}$ starts at time $t$, $O_{4}$ must not start at times where $t \leq s < t + p_{3}$ (after $O_{3}$ has started but before it has been completed using the machine).

One example of a valid configuration is shown below:

|$t$|$x_{3,t}$|$x_{4,t}$|$x_{3,t} \cdot x_{4,t}$|
|---|---|---|---|
|0|1|0|0|
|1|0|0|0|
|2|0|1|0|
|||$\sum_{t} x_{3,t} \cdot x_{4,t} =$|0|
|||**Valid configuration?**|✔|


When we compare $x_{i,t}$ values pairwise at each time in the simulation, their product always equals 0. Further to this, we can see that $O_{4}$ starts two time steps after $O_{3}$, which means that there is no overlap.

Below, we see a configuration that violates the constraint:

|$t$|$x_{3,t}$|$x_{4,t}$|$x_{3,t} \cdot x_{4,t}$|
|---|---|---|---|
|0|0|0|0|
|1|1|1|1|
|2|0|0|0|
|||$\sum_{t} x_{3,t} \cdot x_{4,t} =$|1|
|||**Valid configuration?**|✘|

In this instance, $O_{3}$ and $O_{4}$ are both scheduled to start at $t = 1$ and given they require the same machine, this means that the constraint has been violated. The pairwise product of $x_{i,t}$ values is therefore no longer always equal to 0, as for $t = 1$ we have: $x_{3,1} \cdot x_{4,1} = 1$ 

Another example of an invalid configuration is demonstrated below:

|$t$|$x_{3,t}$|$x_{4,t}$|$x_{3,t} \cdot x_{4,t}$|
|---|---|---|---|
|0|1|0|0|
|1|0|1|0|
|2|0|0|0|
|||$\sum_{t} x_{3,t} \cdot x_{4,t} =$|0|
|||**Valid configuration?**|✘|

In the above scenario, thought the pairwise product is 0 the two operations' running times have overlapped ($t \leq s < t + p_{3}$), and therefore this configuration is not valid.

We can now use this knowledge to mathematically formulate the constraint.

#### Penalty Formulation

As we saw from the tables in the worked example, for the configuration to be valid, the sum of pairwise products of $x_{i,t}$ values for a machine $m$ at any time $t$ must equal 0. This gives you the penalty function:

$$h(x) = \sum_{i,t,k,s} x_{i,t}\cdot x_{k,s} = 0 \text{ for each machine } \textit{m}$$

Let's break that down:

- $\sum_{i,t,k,s}$

  For operation $i$ starting at time $t$, and operation $k$ starting at time $s$, we sum over all possible start times $0 \leq t < T$ and $0 \leq s < T$. This indicates the need for another nested `for` loop, like we used for the precedence constraint.
  
  For this summation, $i \neq k$ (we should always be scheduling two different operations).
  
  For two operations happening on a single machine, $t \neq s$ or the constraint has been violated. If $t = s$ for the operations, they have been scheduled to start on the same machine at the same time, which isn't possible.

- $x_{i,t}\cdot x_{k,s}$

  This is the product we saw explicitly calculated in the rightmost columns of the tables from the worked example. If two different operations $i$ and $k$ start at the same time ($t = s$), this product will equal 1. Otherwise, it will equal 0.
  
- $\sum(\dots) = 0 \text{ for each machine } \textit{m}$

  This sum is performed for each machine $m$ independently.
  
  If all $x_{i,t} \cdot x_{k,s}$ products in the summation equal 0, the total sum comes to 0. This means no operations have been scheduled to start at the same time on this machine and thus the constraint has not been violated. We can see an example of this in the bottom row of the first table from the worked example above.
  
  If any of the $x_{i,t} \cdot x_{k,s}$ products in the summation equal 1, this means that $t = s$ for those operations and therefore two operations have been scheduled to start at the same time on the same machine. The sum now returns a value greater than 1, which gives us a penalty every time the constraint is violated. We can see an example of this in the bottom row of the second table from the worked example.
  
### Code

Using the above, we can transform the final penalty defintion into the `no_overlap_constraint` function. As with the previous two penalty functions, the `weight` is included in the definition of the `Term` objects:

```python
terms = [
    term
    # For each machine
    for ops in machines_ops_map.values()
    # Loop over each operation i requiring this machine
    for i in ops
    # Loop over each operation k requiring this machine 
    for k in ops
    # Loop over simulation time
    for t in range(max_time)
    for term in [
        # t = s meaning two operations are scheduled to start at the same time on the same machine
        Term(c=weight*1, indices=[i*max_time+t, k*max_time+t])
    ] + [
        # Add penalty when operation runtimes overlap
        Term(c=weight*1, indices=[i*max_time+t, k*max_time+s])
        for s in range(t, min(t + processing_time[i], max_time))
    ] + [
        # If operations are in the same job, penalize for the extra time 0 -> t (operations scheduled out of order)
        Term(c=weight*1, indices=[i*max_time+t, k*max_time+s]) if i < k else Term(c=weight*1, indices=[i*max_time+s, k*max_time+t])
        for s in range(0, t)
        if ops_jobs_map[i] == ops_jobs_map[k]
    ]
    # When i != k (when scheduling two different operations)
    if i != k
]
```

## Minimize the makespan

We've represented constraints of the optimization problem with a penalty model, which allows *valid* solutions from the optimizer. The end goal is to obtain an *optimal* (or close to optimal) solution, so we're looking for the schedule with the fastest completion time of all jobs.

The makespan $M$ is defined as the total time required to run all jobs, or alternatively the finishing time of the last job. To minimize this we need to add a fourth component to the cost function that adds larger penalties for solutions with larger makespans:

$$ H(x) = \alpha \cdot f(x) + \beta \cdot g(x) + \gamma \cdot h(x) + \mathbf{\delta \cdot k(x)} $$

We can come up with `Terms` that increase the value of the cost function the further out the last job is completed. Tthe completion time of a job depends solely on the completion time of its final operation; however, since we have no way of knowing in advance what the last job will be, or at which time the last operation will finish, we'll need to include a term for each operation and time step. These terms need to scale with the time parameter $t$, and consider the operation processing time, in order to penalize large makespans over smaller ones.

Some care is required in determining the penalty values, or *coefficients*, of these terms. Recall that we are given a set of operations $\{O_i\}$, which each take processing time $p_i$ to complete. An operation scheduled at time $t$ will then *complete* at time $t + p_i$. Let's define the coefficient $w_t$ as the penalty applied to the cost function for an operation to finish at time $t$. As operations can be scheduled in parallel, we don't know how many might complete at any given time, but do know that this number is at most equal to the number of available machines $m$. The sum of all penalty values for operations completed at time $t$ are thus in the range $[0, ~m \cdot w_t]$. We want to avoid situations were completing a single operation at time $t+1$ is less expensive than $m$ operations at time $t$. Thus, the penalty values cannot follow a simple linear function of time.

Precisely, we want the coefficients to satisfy:
$$ w_{t+1} > m \cdot w_{t} $$

For a suitable parameter $\epsilon > 0$, we can then solve the following recurrence relation:
$$ w_{t+1} = m \cdot w_{t}+\epsilon $$

The simplest solution is given by the function:
$$ w_{t} = \epsilon \cdot \frac{m^t-1}{m-1} $$

### Limiting the number of terms

Before implementing the new terms, let's try to limit the amount of new terms we're adding as much as possible. To illustrate, recall the job shop example:

$$ J_{0} = \{O_{0}, O_{1}, O_{2}\} $$
$$ J_{1} = \{O_{3}, O_{4}, O_{5}\} $$
$$ J_{2} = \{O_{6}, O_{7}, O_{8}, O_{9}\} $$

First, we only need the last operation in every job, as the precedence constraint guarantees that all other operations are completed before it. Given $n$ jobs, we thus consider only the operations $\{O_{k_0-1}, O_{k_1-1}, \dots, O_{k_{n-1}-1}\}$, where the indices $k_j$ denotes the number of operations up to and including job $j$. In this example, we only add terms for the following operations:

$$ \{O_2, O_5, O_9\} $$

$$ \text{with } k_0 = 3, k_1 = 6, k_2 = 10 $$

Next, we can find a lower bound for the makespan and only penalize makespans that are greater than this minimum. A simple lower bound is given by the longest job, as each operation within a job must execute sequentially. We express this lower bound as follows:

$$ M_{lb} = \max\limits_{0 \leq j \lt n} \{ \sum_{i = k_j}^{k_{j+1}-1} p_i \} \leq M $$

For the processing times given in this example, we get:

$$ J_{0} : ~~ p_0 + p_1 + p_2 = 2 + 1 + 3 = 6 $$
$$ J_{1} : ~~ p_3 + p_4 + p_5 = 2 + 2 + 3 = 7 $$
$$ J_{2} : ~~ p_6 + p_7 + p_8 + p_9 = 1 + 2 + 3 + 2 = 8 $$
$$ \Rightarrow M_{lb} = 8 $$

Finally, the makespan is upper-bounded by the sequential execution time of all jobs, 6 + 7 + 8 = 21 in this case. The simulation time T should never exceed this upper bound. Regardless of whether this is the case or not, we need to include penalties for all time steps up to T, or else larger time steps without a penalty will be favored over smaller ones!

To summarize:

- Makespan penalty terms are only added for the last operation in every job $\{O_{k_0-1}, O_{k_1-1}, \dots, O_{k_{n-1}-1}\}$
- The makespan is lower-bounded by the longest job $\Rightarrow$ only include terms for time steps $M_{lb} < t < T$

### Implementing the penalty terms

We are now ready to add the makespan terms to the cost function. Recall that all terms contain a coefficient and one (or multiple) binary decision variables $x_{i,t}$. Contrary to the coefficients $w_t$ defined above, where $t$ refers to the completion time of an operation, the variables $x_{i,t}$ determine if an operation $i$ is *scheduled* at time t. To account for this difference, we'll shift the variable index by the operation's processing time $p_i$. All makespan terms can then be expressed as follows:

$$ k(x) = \sum_{i \in \{k_0-1, \dots, k_{n-1}-1\}} \left( \sum_{M_{lb} < t < T+p_i} w_t \cdot x_{i, ~t-p_i} \right) $$

Lastly, we make a small modification to the coefficient function so that the first value $w_{M_{lb}+1}$ always equals one. With $\epsilon = 1$ and $t_0 = M_{lb}$ we get:

$$ w_{t} = \frac{m^{t-t_0}-1}{m-1} $$

### Code

The code below calculates the penalty coefficient and the overal makespan penalty in the `calculate_penalty` and `makespan_objective` functions.

```python
def calculate_penalty(n_machines: int, t0: int, t: int):
    assert n_machines > 1 # Ensure you don't divide by 0
    return (n_machines**(t - t0) - 1)/float(n_machines - 1)
```
```python
terms = [
    Term(
        c=weight*(calculate_penalty(m_count, lower_bound, t)),
        indices=[(job[-1])*max_time + (t - ops_processing_time[job[-1]])]
    )
    # Loop through the final operation of each job
    for job in jobs_ops_map.values()
    # Loop through each time step the operation could be completion at
    for t in range(lower_bound + 1, max_time + ops_processing_time[job[-1]])
]
```

## Putting it all together

As a reminder, here are the penalty terms:

| Constraint | Penalty condition |
|---|---|
|**Precedence constraint**<br>Operations in a job must take place in order.|Assign penalty every time $O_{i+1}$ starts before $O_{i}$ has finished (they start out of order).|
|**Operation-once constraint**<br>Each operation is started once and only once.|Assign penalty if an operation isn't scheduled within the allowed time.<br>**Assumption:** if an operation starts, it runs to completion.|
|**No-overlap constraint**<br>Machines can only do one thing at a time.|Assign penalty every time two operations on a single machine are scheduled to run at the same time.|

- **Precedence constraint**:

$$f(x) = \sum_{k_{n-1} \leq i < k_n, s < t + p_{i}}x_{i,t}\cdot x_{i+1,s} \text{ for each job } \textit{n}$$

- **Operation-once constraint**:

$$g(x) = \sum_{i} \left(\left(\sum_{0\leq t < T} x_{i,t}\right) - 1\right)^2$$
  
- **No-overlap constraint**:

$$h(x) = \sum_{i,t,k,s} x_{i,t}\cdot x_{k,s} = 0 \text{ for each machine } \textit{m}$$

- **Makespan minimization**:

$$k(x) = \sum_{i \in \{k_0-1, \dots, k_{n-1}-1\}} \left( \sum_{M_{lb} < t < T+p_i} w_t \cdot x_{i, ~t-p_i} \right)$$

As we saw earlier, combining the penalty functions is straightforward - all we do is assign each term a weight and add all the weighted terms together, like so:

$$H(x) = \alpha \cdot f(x) + \beta \cdot g(x) + \gamma \cdot h(x) + \delta \cdot k(x) $$

$$\text{where }\alpha, \beta, \gamma \text{ and } \delta \text{ represent the different weights assigned to the penalties.}$$

The weights represent how important each penalty function is, relative to all the others.

> **NOTE:**
> Along with modifying your cost function (how you represent the penalties), tuning these weights will define how much success you will have solving your optimization problem. There are many ways to represent each optimization problem's penalty functions and many ways to manipulate their relative weights, so this may require some experimentation before you see success. The end of this derivation dives a little deeper into parameter tuning.

### Code

An example of calling the `schedule_jobs` function is given below:

```python
# Set problem parameters
## Allowed time (jobs can only be scheduled below this limit)
max_time = 21 

## Processing time for each operation
ops_processing_time = {0: 2, 1: 1, 2: 3, 3: 2, 4: 2, 5: 3, 6: 1, 7: 2, 8: 3, 9: 2}

## Assignment of operations to jobs (job ID: [operation IDs])
### Operation IDs within a job must be in ascending order
jobs_ops_map = {
    0: [0, 1, 2],   # Pay electricity bill
    1: [3, 4, 5],   # Plan camping trip
    2: [6, 7, 8, 9] # Book dentist appointment
}

## Assignment of operations to machines
### Ten jobs, three machines
machines_ops_map = {
    0: [0, 1, 3, 4, 6, 7],  # Operations 0, 1, 3, 4, 6 and 7 are assigned to machine 0 (the computer)
    1: [2, 5, 8],           # Operations 2, 5 and 8 are assigned to machine 1 (the printer)
    2: [9]                  # Operation 9 is assigned to machine 2 (the tooth floss)
}

result, is_valid = \
    schedule_jobs(jobs_ops_map, ops_processing_time, machines_ops_map,
                  max_time=max_time, timeout=100)
print(f"Valid result: {is_valid}")
print(f"Operation start times: {result['operation_start_times']}")
print(f"Job start times: {result['job_start_times']}")
```

## Tune parameters

Let's take a look at a general method to balance the different components that make up a cost function. If you recall, the cost function is made up of four components, one for each constraint and one to minimize the makespan:

$$ H(x) = \alpha \cdot f(x) + \beta \cdot g(x) + \gamma \cdot h(x) + \delta \cdot k(x) $$

The importance attributed to each term can be adjusted using the weights (coefficients) $\alpha, \beta, \gamma, \text{ and } \delta$, which can be passed to the `schedule_jobs` functions. The process of adjusting these weights is referred to as *parameter tuning*. In general, there's no absolute rule to determine the optimal value for each weight, and you might have to use some trial and error to figure out what works best for your problem. However, the guidelines below can help you get good starting point.

### Automatically adjusting the optimization term weight

Intuitively, it should be clear that satisfying the constraints is more important than minimizing the makespan. An invalid solution, even with a very small makespan, would be useless. The weights of the cost function can be used to reflect this fact; as a rule of thumb, breaking a single constraint should be around 5-10x more expensive than any valid solution.

When calling the `schedule_jobs` function, there is a parameter called `auto_makespan_weight`; if set to `True`, it will ignore any passed `delta` value and generate one from the `alpha`, `beta`, and `gamma` values using the below approach.

Start with an upper bound on the value of the cost function for any valid solution. At worst, a valid solution (meaning that $f(x) = g(x) = h(x) = 0$) contributes at most $m \cdot w_{T-1+max(p_i)}$ to the cost function. This is the case when $m$ operations, all taking $max(p_i)$ to complete, are scheduled at the last time step $T-1$. For convenience, let's say that this should result in a cost function value of $1$. We compute what the value of $\delta$ should be to achieve this value. The code example above uses the following parameters:

$$ m = 3, ~ T = 21, ~ max(p_i) = 3, ~ M_{lb} = 8, ~ w_t = \frac{m^{t-M_{lb}}}{m-1} $$

First, calculate the latest time an operation could finish. This is given by the max time $T$ (minus one because you are using 0-based indexing), plus the longest processing time for any operation ($max(p_i)$):
$$t_{max} = T - 1 + max(p_i) = 21 - 1 + 3 = 23$$

Then, calculate $w_{t_{max}}$:
$$ w_{t_{max}} = \frac{m ^ {t_{max} - M_{lb}}}{m - 1} = \frac{3^{23 - 8}}{3 - 1} = \frac{3^{15}}{2} = 7,174,453.5 $$

The upper bound would be if all the machines finish at this time:

$$ m \cdot w_{t_{max}} = 3 \times 7,174,453.5 = 21,523,360.5 $$

To obtain the desired value of $1$, we can approximately set the weight to:

$$ \delta = \frac{1}{m \cdot w_{t_{max}}} = \frac{1}{21,523,360.5} = 0.00000005 $$

As mentioned in the previous section, breaking a single constraint should incur a penalty roughly 5-10x higher than that of the worst valid solution. To satisfy this, we can adjust $\delta$ to:

$$ \delta_{new} = \delta_{old} \cdot \frac{average(\alpha + \beta + \gamma)}{5} $$

### Adjusting parameters manually

When we run the `schedule_jobs` function, it returns the `results` dictionary and the `is_valid` boolean. If `is_valid` is True then all constraints are satisfied and you have obtained a good solution from the optimizer.

If instead one constraint is consistently broken, you probably need to increase its weight compared to the others. You may also come across situations in which constraints are being broken without a particular preference for which. In this case, make sure the time $T$ given a large enough value. If $T$ is too small, there may not even exist a valid solution, or the solver could be too constrained to feasibly find one.

Optionally, if you're looking for better solutions than the ones obtained so far, you may always try to lower the value of $T$, or increase the importance of the makespan component $\delta$. A tighter bound on the makespan can help the solver find a more optimal solution, as can increasing the weight $\delta$. You may also find that doing so increases the speed at which a solution is found. If any problems pop up with broken constraints, you went too far and need to change the parameters in the other direction again.
